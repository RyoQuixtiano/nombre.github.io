
import React from 'react';
import Header from '@/components/Header';
import ProductList from '@/components/ProductList';
import Footer from '@/components/Footer';
import { Toaster } from '@/components/ui/toaster';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';

const HeroSection = () => (
  <motion.section 
    className="relative py-20 text-center text-white bg-gradient-to-br from-purple-600 via-pink-500 to-orange-400 md:py-32 lg:py-40"
    initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    transition={{ duration: 0.8 }}
  >
    <div className="absolute inset-0 bg-black opacity-30"></div>
    <div className="container relative z-10 max-w-screen-md px-4 mx-auto">
      <motion.h1 
        className="mb-6 text-4xl font-extrabold tracking-tight md:text-5xl lg:text-6xl"
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2, duration: 0.6 }}
      >
        Descubre Artículos <span className="p-1 bg-white rounded-md text-pink-500">Únicos</span> y <span className="p-1 bg-white rounded-md text-purple-600">Especiales</span>
      </motion.h1>
      <motion.p 
        className="mb-8 text-lg md:text-xl text-purple-100"
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.4, duration: 0.6 }}
      >
        Explora nuestra cuidada selección de productos diseñados para inspirar y deleitar.
      </motion.p>
      <motion.div
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.6, duration: 0.6 }}
      >
        <Button size="lg" className="px-8 py-3 text-lg font-semibold text-purple-600 transition-transform duration-300 ease-in-out bg-white hover:bg-gray-100 hover:scale-105" onClick={() => document.getElementById('productos')?.scrollIntoView({ behavior: 'smooth' })}>
          Ver Colección
        </Button>
      </motion.div>
    </div>
    <div className="absolute bottom-0 left-0 w-full overflow-hidden leading-none">
      <svg viewBox="0 0 1440 120" className="relative block w-full h-auto text-background fill-current">
        <path d="M0,96L48,90.7C96,85,192,75,288,80C384,85,480,107,576,112C672,117,768,107,864,90.7C960,75,1056,53,1152,48C1248,43,1344,53,1392,58.7L1440,64L1440,120L1392,120C1344,120,1248,120,1152,120C1056,120,960,120,864,120C768,120,672,120,576,120C480,120,384,120,288,120C192,120,96,120,48,120L0,120Z"></path>
      </svg>
    </div>
  </motion.section>
);

const FeaturedCategories = () => (
  <section className="py-16 bg-background">
    <div className="container max-w-screen-lg px-4 mx-auto">
      <h2 className="mb-10 text-3xl font-bold text-center gradient-text">Categorías Destacadas</h2>
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <motion.div whileHover={{ y: -5 }} className="p-6 text-center transition-shadow duration-300 ease-in-out border rounded-lg shadow-lg hover:shadow-xl bg-card">
          <img  alt="Categoría Gadgets" class="w-24 h-24 mx-auto mb-4 rounded-full object-cover" src="https://images.unsplash.com/photo-1658204212985-e0126040f88f" />
          <h3 className="mb-2 text-xl font-semibold">Gadgets</h3>
          <p className="text-sm text-muted-foreground">Lo último en tecnología.</p>
        </motion.div>
        <motion.div whileHover={{ y: -5 }} className="p-6 text-center transition-shadow duration-300 ease-in-out border rounded-lg shadow-lg hover:shadow-xl bg-card">
          <img  alt="Categoría Decoración" class="w-24 h-24 mx-auto mb-4 rounded-full object-cover" src="https://images.unsplash.com/photo-1691663118633-94108debcd5a" />
          <h3 className="mb-2 text-xl font-semibold">Decoración</h3>
          <p className="text-sm text-muted-foreground">Estilo para tu hogar.</p>
        </motion.div>
        <motion.div whileHover={{ y: -5 }} className="p-6 text-center transition-shadow duration-300 ease-in-out border rounded-lg shadow-lg hover:shadow-xl bg-card">
          <img  alt="Categoría Moda" class="w-24 h-24 mx-auto mb-4 rounded-full object-cover" src="https://images.unsplash.com/photo-1619853650725-25296cc83ddb" />
          <h3 className="mb-2 text-xl font-semibold">Moda</h3>
          <p className="text-sm text-muted-foreground">Tendencias actuales.</p>
        </motion.div>
        <motion.div whileHover={{ y: -5 }} className="p-6 text-center transition-shadow duration-300 ease-in-out border rounded-lg shadow-lg hover:shadow-xl bg-card">
          <img  alt="Categoría Arte" class="w-24 h-24 mx-auto mb-4 rounded-full object-cover" src="https://images.unsplash.com/photo-1600097459519-73ab5c0e7b56" />
          <h3 className="mb-2 text-xl font-semibold">Arte</h3>
          <p className="text-sm text-muted-foreground">Piezas inspiradoras.</p>
        </motion.div>
      </div>
    </div>
  </section>
);


function App() {
  return (
    <div className="flex flex-col min-h-screen bg-background">
      <Header />
      <main className="flex-grow">
        <HeroSection />
        <ProductList />
        <FeaturedCategories />
      </main>
      <Footer />
      <Toaster />
    </div>
  );
}

export default App;
