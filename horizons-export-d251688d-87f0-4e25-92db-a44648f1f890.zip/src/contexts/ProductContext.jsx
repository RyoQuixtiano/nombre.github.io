
import React, { createContext, useState, useEffect, useContext } from 'react';
import { useToast } from '@/components/ui/use-toast';

const ProductContext = createContext();

export const useProducts = () => useContext(ProductContext);

const initialProducts = [
  { id: '1', name: 'Artículo Elegante A', price: 29.99, description: 'Una descripción breve pero atractiva de este artículo.', imagePlaceholder: 'Objeto moderno y minimalista sobre fondo limpio', stock: 10 },
  { id: '2', name: 'Artículo Innovador B', price: 49.99, description: 'Descubre la innovación con este artículo único.', imagePlaceholder: 'Producto tecnológico brillante con detalles futuristas', stock: 5 },
  { id: '3', name: 'Artículo Clásico C', price: 19.99, description: 'Un toque de clase y tradición para tu día a día.', imagePlaceholder: 'Objeto de cuero artesanal con costuras visibles', stock: 15 },
  { id: '4', name: 'Artículo Vibrante D', price: 79.99, description: 'Colores y energía para destacar donde vayas.', imagePlaceholder: 'Accesorio colorido y llamativo con patrones abstractos', stock: 8 },
];

export const ProductProvider = ({ children }) => {
  const [products, setProducts] = useState(initialProducts);
  const [cart, setCart] = useState([]);
  const { toast } = useToast();

  useEffect(() => {
    const storedCart = localStorage.getItem('tiendaOnlineCart');
    if (storedCart) {
      setCart(JSON.parse(storedCart));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('tiendaOnlineCart', JSON.stringify(cart));
  }, [cart]);

  const addToCart = (product, quantity = 1) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.id === product.id);
      if (existingItem) {
        return prevCart.map(item =>
          item.id === product.id ? { ...item, quantity: item.quantity + quantity } : item
        );
      }
      return [...prevCart, { ...product, quantity }];
    });
    toast({
      title: "¡Añadido al carrito!",
      description: `${product.name} ha sido añadido a tu carrito.`,
      className: "bg-green-500 text-white",
    });
  };

  const removeFromCart = (productId) => {
    setCart(prevCart => prevCart.filter(item => item.id !== productId));
    toast({
      title: "Artículo eliminado",
      description: "El artículo ha sido eliminado de tu carrito.",
      variant: "destructive",
    });
  };

  const updateQuantity = (productId, quantity) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prevCart =>
      prevCart.map(item =>
        item.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setCart([]);
    toast({
      title: "Carrito vaciado",
      description: "Todos los artículos han sido eliminados del carrito.",
    });
  };

  const getCartTotal = () => {
    return cart.reduce((total, item) => total + item.price * item.quantity, 0).toFixed(2);
  };

  const getCartItemCount = () => {
    return cart.reduce((count, item) => count + item.quantity, 0);
  };

  return (
    <ProductContext.Provider value={{ products, cart, addToCart, removeFromCart, updateQuantity, clearCart, getCartTotal, getCartItemCount }}>
      {children}
    </ProductContext.Provider>
  );
};
