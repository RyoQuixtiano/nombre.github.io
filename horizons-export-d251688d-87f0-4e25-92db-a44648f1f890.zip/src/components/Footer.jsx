
import React from 'react';
import { Github, Twitter, Facebook, Instagram, PackageOpen } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="py-12 bg-background border-t">
      <div className="container px-4 mx-auto max-w-screen-xl">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-3 lg:grid-cols-4">
          <div>
            <a href="/" className="flex items-center gap-2 mb-4">
              <PackageOpen className="w-8 h-8 text-primary" />
              <span className="text-xl font-bold gradient-text">TuTienda</span>
            </a>
            <p className="text-sm text-muted-foreground">
              Tu destino para artículos únicos y de calidad.
            </p>
          </div>
          <div>
            <h3 className="mb-4 text-lg font-semibold">Enlaces Rápidos</h3>
            <ul className="space-y-2">
              <li><a href="#productos" className="text-sm transition-colors text-muted-foreground hover:text-primary">Productos</a></li>
              <li><a href="#ofertas" className="text-sm transition-colors text-muted-foreground hover:text-primary">Ofertas Especiales</a></li>
              <li><a href="/politica-de-privacidad" className="text-sm transition-colors text-muted-foreground hover:text-primary">Política de Privacidad</a></li>
              <li><a href="/terminos-y-condiciones" className="text-sm transition-colors text-muted-foreground hover:text-primary">Términos y Condiciones</a></li>
            </ul>
          </div>
          <div>
            <h3 className="mb-4 text-lg font-semibold">Contacto</h3>
            <ul className="space-y-2">
              <li><p className="text-sm text-muted-foreground">Email: <a href="mailto:soporte@tutienda.com" className="hover:text-primary">soporte@tutienda.com</a></p></li>
              <li><p className="text-sm text-muted-foreground">Teléfono: <a href="tel:+1234567890" className="hover:text-primary">+1 (234) 567-890</a></p></li>
              <li><p className="text-sm text-muted-foreground">Dirección: Calle Falsa 123, Ciudad</p></li>
            </ul>
          </div>
          <div>
            <h3 className="mb-4 text-lg font-semibold">Síguenos</h3>
            <div className="flex space-x-4">
              <a href="#" className="text-muted-foreground hover:text-primary"><Twitter size={20} /></a>
              <a href="#" className="text-muted-foreground hover:text-primary"><Facebook size={20} /></a>
              <a href="#" className="text-muted-foreground hover:text-primary"><Instagram size={20} /></a>
              <a href="#" className="text-muted-foreground hover:text-primary"><Github size={20} /></a>
            </div>
          </div>
        </div>
        <div className="pt-8 mt-8 text-center text-sm border-t text-muted-foreground">
          © {new Date().getFullYear()} TuTienda. Todos los derechos reservados.
        </div>
      </div>
    </footer>
  );
};

export default Footer;
