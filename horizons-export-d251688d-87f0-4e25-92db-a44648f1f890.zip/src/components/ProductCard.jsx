
import React from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ShoppingCart } from 'lucide-react';
import { useProducts } from '@/contexts/ProductContext';
import { motion } from 'framer-motion';

const ProductCard = ({ product }) => {
  const { addToCart } = useProducts();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      whileHover={{ scale: 1.03, boxShadow: "0px 10px 20px rgba(0,0,0,0.1)" }}
    >
      <Card className="overflow-hidden transition-all duration-300 ease-in-out h-full flex flex-col">
        <CardHeader className="p-0">
          <div className="aspect-w-16 aspect-h-9">
            <img  class="object-cover w-full h-48" alt={product.name} src="https://images.unsplash.com/photo-1697256200022-f61abccad430" />
          </div>
        </CardHeader>
        <CardContent className="p-4 flex-grow">
          <CardTitle className="mb-2 text-xl">{product.name}</CardTitle>
          <CardDescription className="mb-3 text-sm text-muted-foreground h-12 overflow-hidden">{product.description}</CardDescription>
          <p className="text-2xl font-semibold gradient-text">${product.price.toFixed(2)}</p>
        </CardContent>
        <CardFooter className="p-4 pt-0">
          <Button 
            className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white" 
            onClick={() => addToCart(product)}
            disabled={product.stock === 0}
          >
            <ShoppingCart className="w-4 h-4 mr-2" />
            {product.stock > 0 ? 'Añadir al carrito' : 'Agotado'}
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default ProductCard;
