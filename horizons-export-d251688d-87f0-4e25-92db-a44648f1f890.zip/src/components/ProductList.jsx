
import React from 'react';
import ProductCard from '@/components/ProductCard';
import { useProducts } from '@/contexts/ProductContext';
import { motion } from 'framer-motion';

const ProductList = () => {
  const { products } = useProducts();

  if (!products || products.length === 0) {
    return <p className="text-center text-muted-foreground">No hay productos disponibles en este momento.</p>;
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  return (
    <motion.section 
      id="productos" 
      className="py-12 bg-secondary/30"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      <div className="container max-w-screen-xl">
        <h2 className="mb-2 text-4xl font-bold tracking-tight text-center gradient-text">Nuestros Productos</h2>
        <p className="mb-10 text-lg text-center text-muted-foreground">Descubre la colección que hemos preparado para ti.</p>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {products.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </motion.section>
  );
};

export default ProductList;
