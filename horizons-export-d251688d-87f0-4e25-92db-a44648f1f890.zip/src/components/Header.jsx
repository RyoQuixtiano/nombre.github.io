
import React, { useState } from 'react';
import { ShoppingCart, Menu, X, Search, PackageOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useProducts } from '@/contexts/ProductContext';
import { motion, AnimatePresence } from 'framer-motion';

const Header = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const { cart, removeFromCart, updateQuantity, getCartTotal, getCartItemCount, clearCart } = useProducts();

  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);
  const toggleCart = () => setIsCartOpen(!isCartOpen);

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex items-center justify-between h-16 max-w-screen-2xl">
        <a href="/" className="flex items-center gap-2 mr-6">
          <PackageOpen className="w-8 h-8 text-primary" />
          <span className="text-2xl font-bold gradient-text">TuTienda</span>
        </a>

        <nav className="items-center hidden gap-6 text-sm md:flex">
          <a href="#productos" className="font-medium transition-colors text-foreground/60 hover:text-foreground/80">Productos</a>
          <a href="#ofertas" className="font-medium transition-colors text-foreground/60 hover:text-foreground/80">Ofertas</a>
          <a href="#contacto" className="font-medium transition-colors text-foreground/60 hover:text-foreground/80">Contacto</a>
        </nav>

        <div className="flex items-center justify-end flex-1 gap-4">
          <div className="relative hidden sm:block">
            <Search className="absolute w-4 h-4 left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Buscar productos..." className="pl-10 w-64" />
          </div>
          <Button variant="ghost" size="icon" onClick={toggleCart} className="relative">
            <ShoppingCart className="w-6 h-6" />
            {getCartItemCount() > 0 && (
              <span className="absolute top-0 right-0 flex items-center justify-center w-5 h-5 text-xs text-white bg-red-500 rounded-full">
                {getCartItemCount()}
              </span>
            )}
          </Button>
          <Button variant="outline" className="hidden lg:inline-flex">Iniciar Sesión</Button>
          <Button onClick={toggleMobileMenu} variant="ghost" size="icon" className="md:hidden">
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </Button>
        </div>
      </div>

      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-16 left-0 right-0 z-40 p-4 bg-background border-b md:hidden"
          >
            <nav className="flex flex-col gap-4">
              <Input placeholder="Buscar productos..." className="w-full" />
              <a href="#productos" className="font-medium" onClick={toggleMobileMenu}>Productos</a>
              <a href="#ofertas" className="font-medium" onClick={toggleMobileMenu}>Ofertas</a>
              <a href="#contacto" className="font-medium" onClick={toggleMobileMenu}>Contacto</a>
              <Button variant="outline">Iniciar Sesión</Button>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isCartOpen && (
          <motion.div
            initial={{ opacity: 0, x: "100%" }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: "100%" }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="fixed top-0 right-0 z-50 w-full h-full max-w-md bg-background shadow-xl"
          >
            <Card className="flex flex-col h-full border-0 rounded-none">
              <CardHeader className="flex flex-row items-center justify-between p-4 border-b">
                <CardTitle className="text-xl">Tu Carrito</CardTitle>
                <Button variant="ghost" size="icon" onClick={toggleCart}>
                  <X className="w-5 h-5" />
                </Button>
              </CardHeader>
              <CardContent className="flex-grow p-4 overflow-y-auto">
                {cart.length === 0 ? (
                  <p className="text-center text-muted-foreground">Tu carrito está vacío.</p>
                ) : (
                  <ul className="space-y-4">
                    {cart.map(item => (
                      <li key={item.id} className="flex items-center gap-4 p-2 border rounded-md">
                        <img  alt={item.name} class="w-16 h-16 object-cover rounded" src="https://images.unsplash.com/photo-1694878981885-7647baf0d957" />
                        <div className="flex-grow">
                          <h4 className="font-semibold">{item.name}</h4>
                          <p className="text-sm text-muted-foreground">${item.price.toFixed(2)}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Input
                            type="number"
                            min="1"
                            value={item.quantity}
                            onChange={(e) => updateQuantity(item.id, parseInt(e.target.value))}
                            className="w-16 h-8 text-center"
                          />
                          <Button variant="ghost" size="icon" onClick={() => removeFromCart(item.id)}>
                            <X className="w-4 h-4 text-destructive" />
                          </Button>
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
              </CardContent>
              {cart.length > 0 && (
                <CardFooter className="flex-col gap-4 p-4 border-t">
                  <div className="flex justify-between w-full font-semibold">
                    <span>Total:</span>
                    <span>${getCartTotal()}</span>
                  </div>
                  <Button className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white">Proceder al Pago</Button>
                  <Button variant="outline" className="w-full" onClick={clearCart}>Vaciar Carrito</Button>
                </CardFooter>
              )}
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;
